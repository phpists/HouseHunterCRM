import styled from "styled-components";
import { RequestCard } from "./RequestCard/RequestCard";

export const List = () => {
  return (
    <StyledList className="hide-scroll">
      <RequestCard />
      <RequestCard />
      <RequestCard />
      <RequestCard />
    </StyledList>
  );
};

const StyledList = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  grid-auto-rows: auto;
  height: calc(100svh - 225px);
  overflow: auto;
  gap: 10px;
`;
