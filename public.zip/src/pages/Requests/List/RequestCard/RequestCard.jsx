import styled from "styled-components";
import { Client } from "./Client/Client";
import { Date } from "./Date/Date";
import { Info } from "./Info/Info";
import { Comment } from "./Comment";

export const RequestCard = () => {
  return (
    <StyledRequestCard>
      <Client />
      <Date />
      <Info />
      <Comment />
    </StyledRequestCard>
  );
};

const StyledRequestCard = styled.div`
  display: grid;
  grid-template-columns: repeat(6, max-content);
  gap: 14px;
  border-radius: 10px;
  background: #3d3d3d;
  padding: 10px;
`;
