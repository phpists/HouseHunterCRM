import styled from "styled-components";
import { Header } from "./Header/Header";
import { List } from "./List/List";

export const Requests = () => {
  return (
    <StyledRequests>
      <Header />
      <List />
    </StyledRequests>
  );
};

const StyledRequests = styled.div`
  background: #323232;
  box-shadow: 0px 3px 32px 0px rgba(0, 0, 0, 0.22);
  padding: 15px 20px;
  position: relative;
`;
