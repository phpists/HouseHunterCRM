import { styled } from "styled-components";
import { Card } from "./Card/Card";

export const List = () => {
  const data = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  return (
    <StyledList className="hide-scroll">
      {data.map((e, i) => (
        <Card key={i} />
      ))}
    </StyledList>
  );
};

const StyledList = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 10px;
  overflow: auto;
  height: calc(100svh - 256px);
`;
