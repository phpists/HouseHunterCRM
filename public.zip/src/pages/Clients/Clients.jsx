import { styled } from "styled-components";
import { Header } from "./Header/Header";
import { List } from "./List/List";

export const Clients = () => {
  return (
    <StyledClients>
      <Header />
      <List />
    </StyledClients>
  );
};

const StyledClients = styled.div`
  background: #323232;
  box-shadow: 0px 3px 32px 0px rgba(0, 0, 0, 0.22);
  width: 100%;
  padding: 18px 20px 14px;
`;
