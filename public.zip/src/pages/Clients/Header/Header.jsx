import { styled } from "styled-components";
import { Title } from "./Title";
import { Buttons } from "./Buttons/Buttons";

export const Header = () => {
  return (
    <StyledHeader className="flex items-center justify-between">
      <Title title="12 нових клієнтів за сьогодні" />
      <Buttons />
    </StyledHeader>
  );
};

const StyledHeader = styled.div`
  margin-bottom: 18px;
  position: relative;
`;
