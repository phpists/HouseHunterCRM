import { styled } from "styled-components";
import { Option } from "./Option";
import { motion } from "framer-motion";

export const Dropdown = ({ open }) => (
  <StyledDropdown
    className="hide-scroll select-none"
    animate={{ opacity: open ? 1 : 0, visibility: open ? "visible" : "hidden" }}
  >
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
    <Option title="Квартиры" onSelect={() => null} />
  </StyledDropdown>
);

const StyledDropdown = styled(motion.div)`
  position: absolute;
  top: 100%;
  width: 100%;
  right: 0;
  background: #fff;
  border-radius: 0 0 6px 6px;
  max-height: 182px;
  overflow: auto;
  border-top: 1px solid rgba(0, 0, 0, 0.2);
`;
