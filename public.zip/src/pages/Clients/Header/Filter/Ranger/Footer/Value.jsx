import { styled } from "styled-components";

export const Value = ({ from, to, type }) => {
  const typeValue = type ? ` ${type}` : "";

  return (
    <StyledValue>
      {from}
      {typeValue} - {to}
      {typeValue}
    </StyledValue>
  );
};

const StyledValue = styled.div`
  border-radius: 4px;
  background: #3d3d3d;
  padding: 3px 9px 4px 10px;
  color: #fff;
  font-family: Open Sans;
  font-size: 11px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
  letter-spacing: 0.22px;
`;
