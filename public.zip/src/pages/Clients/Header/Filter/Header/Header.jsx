import { styled } from "styled-components";
import { Title } from "./Title";
import { Close } from "./Close";

export const Header = () => (
  <StyledHeader className="flex items-center justify-between">
    <Title />
    <Close />
  </StyledHeader>
);

const StyledHeader = styled.div`
  margin-bottom: 20px;
  padding: 18px 20px 20px;
`;
