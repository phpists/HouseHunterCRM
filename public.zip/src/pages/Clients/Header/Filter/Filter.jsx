import { styled } from "styled-components";
import { Header } from "./Header/Header";
import { SectionTitle } from "./SectionTitle";
import { General } from "./General";
import { Topicality } from "./Topicality";

export const Filter = () => {
  return (
    <StyledFilter>
      <Header />
      <div className="content">
        <SectionTitle title="Головне" />
        <General />
        <SectionTitle title="Актуальність" />
        <Topicality />
        <SectionTitle title="Характеристики" />
      </div>
    </StyledFilter>
  );
};

const StyledFilter = styled.div`
  position: absolute;
  top: -18px;
  right: -20px;
  width: 439px;
  height: calc(100svh - 173px);
  flex-shrink: 0;
  background: rgba(44, 44, 44, 0.8);
  backdrop-filter: blur(12.5px);
  z-index: 20;
  .content {
    padding: 0 20px 20px;
    height: calc(100svh - 173px - 70px - 20px);
    overflow: auto;
  }
`;
