import { styled } from "styled-components";
import { ReactComponent as SearchIcon } from "../../../../assets/images/search.svg";
import { Button } from "./Button";
import { Filter } from "../Filter/Filter";

export const Search = () => {
  return (
    <div className="mr-2.5">
      <Button Icon={SearchIcon} onClick={null} />
      <Filter />
    </div>
  );
};

// const StyledFilter = styled.div``;
