import styled from "styled-components";
import { Header } from "./Header/Header";
import { List } from "./List";

export const Objects = () => {
  return (
    <StyledObjects>
      <Header />
      <List />
    </StyledObjects>
  );
};

const StyledObjects = styled.div`
  padding: 15px 20px;
  background: #323232;
  box-shadow: 0px 3px 32px 0px rgba(0, 0, 0, 0.22);
  position: relative;
`;
