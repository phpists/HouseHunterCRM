import styled from "styled-components";
import { Contact } from "./Contact/Contact";

export const Contacts = () => {
  return (
    <StyledContacts>
      <Contact type="owner" />
    </StyledContacts>
  );
};

const StyledContacts = styled.div``;
