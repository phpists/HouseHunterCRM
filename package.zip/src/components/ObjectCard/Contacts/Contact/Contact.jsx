import styled from "styled-components";
import { Name } from "./Name";
import { Phone } from "./Phone/Phones";
import { useState } from "react";
import { CommentButton } from "./CommentButton";

export const Contact = ({ type }) => {
  const [commentOpen, setCommentOpen] = useState(false);

  return (
    <StyledContact>
      <div className="flex items-center">
        <CommentButton
          active={commentOpen}
          onClick={() => setCommentOpen(!commentOpen)}
        />
        <Name type={type} />
      </div>
      {commentOpen && <div className="comment-wrapper">commentOpen</div>}
      <Phone commentOpen={commentOpen} />
    </StyledContact>
  );
};

const StyledContact = styled.div`
  .comment-wrapper {
    margin: 10px 0 4px;
  }
`;
