import styled from "styled-components";
import { Header } from "./Header/Header";
import { Text } from "./Text";
import { Footer } from "./Footer/Footer";

export const Info = () => {
  return (
    <StyledInfo className="flex flex-col justify-between">
      <Header />
      <Text />
      <Footer />
    </StyledInfo>
  );
};

const StyledInfo = styled.div`
  margin-right: 10px;
  min-height: 200px;
`;
