import styled from "styled-components";
import { Slider } from "./Slider/Slider";
import { MainInfo } from "./MainInfo/MainInfo";
import { Info } from "./Info/Info";
import { Tags } from "./Tags/Tags";
import { Contacts } from "./Contacts/Contacts";
import { ShowMore } from "./ShowMore/ShowMore";

export const ObjectCard = () => {
  return (
    <StyledObjectCard className="">
      <Slider />
      <MainInfo />
      <Info />
      <Tags />
      <Contacts />
      <ShowMore />
    </StyledObjectCard>
  );
};

const StyledObjectCard = styled.div`
  padding: 20px;
  border-radius: 10px;
  background: #3d3d3d;
  height: max-content;
  display: grid;
  grid-template-columns: repeat(5, max-content);
  position: relative;
`;
